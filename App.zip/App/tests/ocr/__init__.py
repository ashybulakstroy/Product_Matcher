"""Ported OCR regression tests."""
